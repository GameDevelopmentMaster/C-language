#include<stdio.h>
#include<stdlib.h>	
int main() {
	int n,num,count;
	scanf_s("%d", &n);
	int * a = (int*)malloc(sizeof(int)*n*2);
	for (int i = 0; i < n; i++) {
		scanf_s("%d", &a[i]);
	}
	scanf("%d", &num);
	for (int i = num; i < n;i++) {
		for (int j = 1; j < n; j++) {
			if (num * 2 + j == i * 2 + 1) {
				a[i*2+1] = -2;
			}
		}
		
	}
	
	for (int i = 0; i < n; i++) {
		if (a[i] != -2) {
			count++;
		}
	}
	printf("%d", count);
}