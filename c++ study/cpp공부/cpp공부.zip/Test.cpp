#include<stdio.h>
#include<stdlib.h>
int main() {
	int n,count,max=0;
	scanf_s("%d", &n);
	int *chick = (int*)malloc(sizeof(int)*(n+1));
	for (int i = 0; i < n; i++) {
		scanf_s("%d", &chick[i]);
	}
	chick[n + 1] = 0;
	for (int i = 0; i < n; i++) {
		for (int j = i; j < n; j++) {
			if (chick[i] > chick[j+1]) {
				count = chick[i];
				chick[i] = chick[j + 1];
				chick[j + 1] = count;
			}
		}
	}
	count = 0;
	for (int i = 0; i < n;i++) {
		if (count != 5) {
			if (chick[i+1] - chick[i] == 1) {
				count++;
			}
			else {
				if (max < count) {
					max = count;
				}
				count = 0;
			}
		}
	}
	if (max < count) {
		max = count;
	}
	max++;
	printf("%d", 5-max);
}